# Dan's Bistro (Daily Specials)
This demo shows students how they can use JavaScript to get an element of date (day of the week) and use it to display a daily special for a fictional bistro.  The list of specials is below:

## Monday - $12 Chicken Penne Alfredo
Grilled chicken breast over penne noodles with a creamy Alfredo sauce and parmesan cheese on top.  Side Caesar Salad included.

## Tuesday - $10 Any Small Pizza
Pick up to 3 of your favourite toppings. Our pizzas have a crispy golden whole wheat crust.

## Wednesday - 35¢ Chicken Wings
Our classic chicken wings come in three flavours – salt & pepper, honey garlic and extra hot. Minimum order is 20 wings – available in quantities of 10 after that.

## Thursday - $9 Fish and Chips
Authentic English style battered cod with a heaping helping of piping hot chips. Served with salt, vinegar and a curry sauce to flavor it to your taste. This dish is jolly good!

## Friday - Half Price Cocktails All Day
50% off our regular price. Our customers rave about our Greek Salad, so we want to give everyone a chance to try it.  Get a full sized Greek Salad at a great price.

## Saturday - $10 Jumbo Greek Salad
50% off our regular price. Our customers rave about our Greek Salad, so we want to give everyone a chance to try it.  Get a full sized Greek Salad at a great price.

## Sunday - $9 Deluxe Burger & Fries
50% off our Deluxe Burger and fries. A 16oz Angus patty on a pretzel bun topped with lettuce, tomato, bacon, grilled onions, and an onion ring. A huge side of our famous fries is served on the side.
